var valorEmDolar = prompt ("Quanto você tem na carteira?");
var cotacaoDoDolar = 5.12;
//var nome = "Rafaela";
var nome = prompt("Qual é o seu nome:")
var valorEmReal = valorEmDolar * cotacaoDoDolar;
valorEmReal = valorEmReal.toFixed(2);
alert("Olá "+nome+ " , o valor após conversão é R$ "  + valorEmReal);
